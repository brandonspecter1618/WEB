$(Document).ready(function working(){
    //Default colors
    var color=Array(4);
    color['Blue']='#0d6efd'
    color['Purple']= '#6f42c1';
    color['Dark']= '#212529';
    color['Gray']= '#6c757d';
    color['Pink']= '#d63384';
    $('#submit_theme_val').click(function(){
    //Geting theme
    var theme = document.querySelector("#themes");
    var option = theme.children[theme.selectedIndex];
    var theme_val= option.textContent;
    //sething theme
    setTheme()
    function setTheme(){
               $('.calculadora-area').css(
                   'background-color',color[theme_val]
               ) 
               $('.tecla').css(
                   'border',`3px solid ${color[theme_val]}`
               )
               $('#scream').css(
                   'color',color[theme_val]
               )
               console.log(`Theme changed to ${theme_val} with value =
               . ${color[theme_val]}`)
    }
   })
})


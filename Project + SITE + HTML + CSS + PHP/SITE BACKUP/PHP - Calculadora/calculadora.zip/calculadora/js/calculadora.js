$(document).ready(function(){
    var debugue='';
    var display = document.getElementById("scream");
    var resultarea=document.getElementById('resultarea');
    var logs = document.getElementById('logs');
    var result;
    var operador;
    var gateway= $("#scream")
    var debug = $("#resultarea");

    //function change de Ids
    var igual_counts=0;
    igualcounter()
    function igualcounter(){
        $('.tecla').click(function(){
            var valida = this.id
            validar(valida)
        })
        function validar(valida){
            if(valida=='i-='){
                
                igual_counts+=1;
                creatData()
            }
        }   
    }
    function creatData(){
        var data = document.createElement('p');
        data.setAttribute('id',`p-${igual_counts}`)
            data.innerHTML+=debugue;
            appendingThisChild(data)
    }
    //typing audio
    var typing = document.createElement('audio');
        typing.setAttribute('src','./audio/typing.mp3')
        typing.volume=0.1
        typing.currentTime=0.1
   
    
    $(".tecla").click(function(){ 
    
        tecla_id= this.id;
        adicionador(tecla_id)
    })
    function adicionador(tecla_id_parametro){

        tecla_val=tecla_id_parametro.split("-");
        debugue+=tecla_val[1];
        display.innerHTML+=tecla_val[1]   
        //passando o val para proxima funcao
        condicoes(tecla_val[1])
    }
    function condicoes(tecla_val){

        //playing typin audio
       $('.tecla').click(function(){
        typing.play()
        display.appendChild(typing)
       })
       
     
        switch(tecla_val){
            case 'x':
                operador = 'x';
            
                break;
            case '+':
                operador="+";
                break;
            
            case '=':
                
              
                membros=debugue.split(operador);
                //Data breaklines
               var br = document.createElement('br');
                    var c =document.getElementById(`p-${igual_counts}`)
                    c.appendChild(br);

                if(operador=='x'){
                    result= parseFloat(membros[0]) * parseFloat(membros[1]);
                    resultarea.innerHTML=result;
                    debugue+=result
                    
                }else if(operador=='+'){
                    result= parseInt(membros[0]) + parseInt(membros[1])
                    resultarea.innerHTML=result;
                    debugue+=result
                    
                   
                }else{
                  function badGateway(){
                    
                    gateway.html(
                        'Erro'
                    )
                    
                    gateway.css('color','red')
                    gateway.css('text-align','center')
                    
                    debug.css('color','red')
                    debug.css(
                           'border','1px solid #0d6efd'
                    )
                    debug.html(
                        ' :( Selecione um operador([x]/[+])'     
                    )
                    debug.css('text-align','center')
                    debug.css('font-size','9pt')
                    
                  }
                   badGateway()
                    var badgateway = document.createElement('audio');
                        badgateway.setAttribute('src','./audio/badgateway.wav')
                        badgateway.play()
                        badgateway.currentTime=0.1
                        display.appendChild(badgateway)
                   
                }   
                break;
                case ' ':
                //Data cleaner
                logs.innerHTML+= 'Limpar Dados'
                display.innerHTML='';
                debugue='';
                operador='';
                result='';
                resultarea.innerHTML='' 
                
                function clearbadGateway(){
                    gateway.html(
                        '')
                    gateway.css(
                        'text-align','initial'
                    )
                    gateway.css(
                        'color',''
                    )
                    debug.css(
                        'text-align','initial'
                    )
                    debug.css(
                        'color',''
                    )
                    debug.css(
                        'font-size','24pt'
                    )
                    debug.css(
                        'border',''
                 )
                  }
                clearbadGateway()
                break; 

}           
            
            console.log(`debuger = '${debugue}'`);
            console.log(` Operador = '${operador}'`);
            console.log(`Resultado = ${result}`); 
            logs.innerText=`Memória = '${debugue}` 
            logs.innerHTML+='<br/>'   
            logs.innerText+= `Operador = '${operador}'`;
            logs.innerHTML+='<br/>'  
            logs.innerText+= `Result = '${result}'`
            
}
function appendingThisChild(data){
                logs.appendChild(data);}            
})


